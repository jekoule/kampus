// @flow
import saveUserCommunityPermissions from './saveUserCommunityPermissions';

module.exports = {
  Mutation: {
    saveUserCommunityPermissions,
  },
};
