// @flow
import uploadImage from './uploadImage';

module.exports = {
  Mutation: {
    uploadImage,
  },
};
