// @flow
import toggleReaction from './toggleReaction';

module.exports = {
  Mutation: {
    toggleReaction,
  },
};
