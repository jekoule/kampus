// @flow
/*

Deprecated Oct 26 2018 by @brian

*/
import type { DBThread } from 'shared/types';

export default () => [];
