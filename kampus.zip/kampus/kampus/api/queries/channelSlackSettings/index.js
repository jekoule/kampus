// @flow
import botLinks from './botLinks';

module.exports = {
  ChannelSlackSettings: {
    botLinks,
  },
};
