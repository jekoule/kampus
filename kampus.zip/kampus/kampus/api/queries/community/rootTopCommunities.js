// @flow
import { getCuratedCommunities } from '../../models/curatedContent';
export default () => getCuratedCommunities('top-communities-by-members');
