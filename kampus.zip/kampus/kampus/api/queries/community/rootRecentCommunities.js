// @flow
import { getRecentCommunities } from '../../models/community';
export default () => getRecentCommunities();
