// @flow
export const TRACK_ANALYTICS = 'track analytics';
export const IDENTIFY_ANALYTICS = 'identify analytics';
