// @flow
// $FlowFixMe
import createBrowserHistory from 'history/createBrowserHistory';

export const history = createBrowserHistory();
